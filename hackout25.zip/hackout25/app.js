// Seed Data
const reports = [
  { id: "r1", type: "Mangrove Cutting", description: "Freshly cut stumps near estuary.", status: "pending", lat: 21.64, lng: 69.60, createdAt: "2025-08-30 10:00" },
  { id: "r2", type: "Waste Dumping", description: "Plastic debris found along creek.", status: "validated", lat: 19.07, lng: 72.87, createdAt: "2025-08-30 08:00" }
];
const leaders = [
  { rank: 1, name: "Asha", region: "Kutch", reports: 12, points: 640 },
  { rank: 2, name: "Ravi", region: "Mumbai", reports: 9, points: 520 }
];

// Tabs
document.querySelectorAll("nav button").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("nav button").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab").forEach(tab => tab.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).classList.add("active");
  });
});

// Feed
function loadFeed() {
  const feed = document.getElementById("feedList");
  feed.innerHTML = reports.map(r => `
    <div class="report-card">
      <h4>${r.type} <span class="badge ${r.status}">${r.status}</span></h4>
      <p>${r.description}</p>
      <small>📍 ${r.lat}, ${r.lng} | 🕒 ${r.createdAt}</small>
    </div>
  `).join("");
}

// Leaderboard
function loadLeaderboard() {
  const tbody = document.getElementById("leaderboardList");
  tbody.innerHTML = leaders.map(l => `
    <tr>
      <td>${l.rank === 1 ? "🥇" : l.rank === 2 ? "🥈" : l.rank === 3 ? "🥉" : l.rank}</td>
      <td>${l.name}</td><td>${l.region}</td><td>${l.reports}</td>
      <td><progress value="${l.points}" max="1000"></progress> ${l.points}</td>
    </tr>
  `).join("");
}

// Dashboard
function loadDashboard() {
  const tbody = document.getElementById("dashboardList");
  tbody.innerHTML = reports.map(r => `
    <tr>
      <td>${r.id}</td><td>${r.type}</td>
      <td><span class="badge ${r.status}">${r.status}</span></td>
      <td>${r.lat},${r.lng}</td><td>${r.createdAt}</td>
    </tr>
  `).join("");
  document.getElementById("stats").innerHTML =
    `<div class="report-card"><b>Total:</b> ${reports.length} | <b>Validated:</b> ${reports.filter(r=>r.status==="validated").length}</div>`;
}

// Form
document.getElementById("reportForm").addEventListener("submit", e => {
  e.preventDefault();
  const form = e.target;
  const data = {
    id: "r"+(reports.length+1),
    type: form.type.value,
    description: form.description.value,
    status: "pending",
    lat: form.lat.value || "0",
    lng: form.lng.value || "0",
    createdAt: new Date().toLocaleString()
  };
  reports.push(data);
  const msg = document.getElementById("reportMessage");
  msg.className = "success";
  msg.innerText = "✅ Report submitted successfully!";
  loadFeed(); loadDashboard();
  form.reset();
});

// Location
document.getElementById("getLocation").addEventListener("click", () => {
  navigator.geolocation.getCurrentPosition(pos => {
    document.getElementById("lat").value = pos.coords.latitude.toFixed(4);
    document.getElementById("lng").value = pos.coords.longitude.toFixed(4);
  });
});

// Init
loadFeed();
loadLeaderboard();
loadDashboard();
